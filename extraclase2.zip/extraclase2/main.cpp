#include<iostream>
#include "Empleado.h"


int cantDeTrabajadoresExcelentes(Empleado planillaVector[], double tamanoDelVector);
Empleado elEmpleadoQueGanaMas(Empleado planillaVector[], double tamanoDelVector);

int main (int argc, char *argv[]) {
	string Nombre;
	int Id;
	float HorasMes, precioHora;
	char categoria;
	int antiguedad;
	int tamano;
	
	cout << "Ingrese la cantidad de empleados: ";
	cin >> tamano;
	
	Empleado planilla[tamano];
	
	for(int i = 0; i < tamano; i++){
		
		cout << "Ingrese nombre del trabajador: ";
		cin >> Nombre;
		cout << "Ingrese numero de cedula: ";
		cin >> Id;
		cout << "Ingrese horas trabajadas al mes: ";
		cin >> HorasMes;
		cout << "Ingrese precio por hora: ";
		cin >> precioHora;
		cout << "Ingrese categoria (e/b/r): ";
		cin >> categoria;
		cout << "Ingrese el tiempo que tienes trabajando: ";
		cin >> antiguedad;
		
		// Crear un objeto Empleado con los datos ingresados
		Empleado empleado(Nombre, Id, HorasMes, precioHora, categoria, antiguedad);
		planilla[i]=empleado;
		
		// Mostrar los datos del empleado en pantalla
		cout << "Datos del empleado #"<< endl;
		cout << empleado.toString() << endl;
		cout<< "las horas extras son: "<<empleado.calcularHorasExtra()<<endl;
		cout << "Salario Bruto: " << empleado.calcularSalarioBruto() << endl;
		cout << "Salario Neto: " << empleado.calcularSalarioNeto() << endl;
		cout << "------------------------" << endl;
	}
	
	cout << "Trabajador que gana mas: " << elEmpleadoQueGanaMas(planilla, tamano).getnombre() << endl;
	cout << "Cantidad de trabajadores excelentes: " << cantDeTrabajadoresExcelentes(planilla, tamano) << endl;
	
	
	
	return 0;

}

Empleado elEmpleadoQueGanaMas(Empleado planillaVector[], double tamanoDelVector){
	
	Empleado mayor = planillaVector[0];
	for (int i = 0; i < tamanoDelVector; i++){
		if ( planillaVector[i].calcularSalarioNeto() > mayor.calcularSalarioNeto() ){
			mayor = planillaVector[i];
		}
	}
	return mayor;
	
}

	
int cantDeTrabajadoresExcelentes(Empleado planillaVector[], double tamanoDelVector){
	int contador = 0;
	for (int i = 0; i < tamanoDelVector; i++){
		
		if (planillaVector[i].getcategoria() == 'e' ){
			contador +=1;
		}
		
	}
	return contador;
}

Empleado::Empleado() {
	nombre = " ";
	cedula = 0;
	horasTrabajadas = 0;
	precioPorHora = 0;
	categoria = ' ';
	anosDeServicio = 0;
}

Empleado::~Empleado() {
}

Empleado::Empleado(string nombre, int cedula, int horasTrabajadas, double precioPorHora, char categoria, int anosDeServicio) {
	this->nombre = nombre;
	this->cedula = cedula;
	this->horasTrabajadas = horasTrabajadas;
	this->precioPorHora = precioPorHora;
	this->categoria = categoria;
	this->anosDeServicio = anosDeServicio;
}

void Empleado::Setnombre(string nombre) {
	this->nombre = nombre;
}

void Empleado::Setcedula(int cedula) {
	this->cedula = cedula;
}

void Empleado::SethorasTrabajadas(int horasTrabajadas) {
	this->horasTrabajadas = horasTrabajadas;
}

void Empleado::SetprecioPorHora(int precioPorHora) {
	this->precioPorHora = precioPorHora;
}

void Empleado::Setcategoria(char categoria) {
	this->categoria = categoria;
}

void Empleado::SetanosDeServicio(int anosDeServicio) {
	this->anosDeServicio = anosDeServicio;
}

string Empleado::getnombre() {
	return nombre;
}

int Empleado::getcedula() {
	return cedula;
}

char Empleado::getcategoria() {
	return categoria;
}

double Empleado::getprecioPorHora() {
	return precioPorHora;
}

int Empleado::gethorasTrabajadas() {
	return horasTrabajadas;
}

int Empleado::getAnosDeServicio() {
	return anosDeServicio;
}

string Empleado::toString() {
	stringstream s; 
	s <<"Nombre del empleado: "<< nombre << endl;
	s <<"Cedula del empleado: "<< cedula << endl;
	s <<"Categoria del empleado: "<< categoria << endl;
	s <<"Precio por cada hora trabajada: "<< precioPorHora << endl;
	s <<"Horas trabajadas por el empleado: "<< horasTrabajadas << endl;
	s <<"Anios de servicio del empleado: "<< anosDeServicio << endl;
	return s.str();
}

double Empleado::calcularHorasExtra() {
	if (horasTrabajadas > 48) {
		return (horasTrabajadas - 48) * precioPorHora * 1.5;
	}
	return 0;
}

double Empleado::calcularSalarioBruto() {
	double salarioBruto;
	if(horasTrabajadas < 48){
		salarioBruto = horasTrabajadas * precioPorHora;
	} else {
		salarioBruto = 48 * precioPorHora;
	}
	salarioBruto += calcularHorasExtra();
	return salarioBruto;
}

double Empleado::calcularRebajo() {
	return calcularSalarioBruto() * 0.08;
}

double Empleado::calcularIncentivos() {
	float incentivo = 0;
	float salarioBruto = calcularSalarioBruto();
	if (categoria == 'e') {
		incentivo += salarioBruto * 0.05;
		if (anosDeServicio > 10) {
			incentivo += anosDeServicio * 0.03;
		} else if (anosDeServicio > 5) {
			incentivo += 50000;
		}
	} else if (categoria == 'b') {
		incentivo += salarioBruto * 0.03;
	} else if (categoria == 'r') {
		incentivo += salarioBruto * 0.01;
	}
	return incentivo;
}

double Empleado::calcularSalarioNeto() {
	double salarioNeto = calcularSalarioBruto() + calcularIncentivos() - calcularRebajo();
	return salarioNeto;
}

