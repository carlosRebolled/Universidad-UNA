#ifndef EMPLEADO_H
#define EMPLEADO_H

#include <string>
#include <sstream>
using namespace std;

class Empleado {
public:
	Empleado();
	Empleado(string, int, int, double, char, int);
	~Empleado();
	
	void Setnombre(string nombre);
	void Setcedula(int cedula);
	void SethorasTrabajadas(int horasTrabajadas);
	void SetprecioPorHora(int precioPorHora);
	void Setcategoria(char categoria);
	void SetanosDeServicio(int anosDeServicio);
	
	string getnombre();
	int getcedula();
	char getcategoria();
	double getprecioPorHora();
	int gethorasTrabajadas();
	int getAnosDeServicio();
	string toString();
	
	double calcularHorasExtra();
	double calcularSalarioBruto();
	double calcularRebajo();
	double calcularIncentivos();
	double calcularSalarioNeto();
	
private:
	string nombre;
	int cedula;
	int horasTrabajadas;
	double precioPorHora;
	char categoria;
	int anosDeServicio;
};

#endif
