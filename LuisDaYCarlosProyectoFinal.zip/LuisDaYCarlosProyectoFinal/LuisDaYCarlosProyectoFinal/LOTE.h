#ifndef LOTE_H
#define LOTE_H

#include <iostream>
#include <sstream>

using namespace std;

class Lote {
public:
    Lote();
    ~Lote();

    void setId(int id);
    void setEstado(char estado);
    void setNombreC(string nombreC);
    void setIdC(int idC);
    void setCant_repisa(int cant_repisa);
    void setCat_riego(bool cat_riego);
    void setServicio(bool servicio);
    void setPrecioSer(float precioSer);
    void setPrecio_riego(float precio_riego);
    void setIVA(float iva);
    void setPrecio_lote(float precio_lote);
    void setDisp_lote(bool disp_lote);
    void setCalcu_precio(float calcu_precio);
    void setTipo_asper(bool tipo_asper);

    // getters
    int getId();
    char getEstado();
    string getNombreC();
    int getIdC();
    int getCant_repisa();
    bool getCat_riego();
    bool getServicio();
    float getPrecioSer();
    float getPrecio_riego();
    float getIVA();
    float getPrecio_lote();
    bool getDisp_lote();
    float getCalcu_precio();
    bool getTipo_asper();

    void calcular_iva();
    void calcular_precio_total();
    double calcular_precio_5porciento();
    double calcular_precio_15porciento();
    double n_lotes_disponibles(Lote vector_lotes[10]);
    void set_estado_lote(char estado_lote);
    string to_string();

private:
    int Id;
    char Estado;
    string NombreC;
    int IdC;
    int Cant_repisa;
    bool Cat_riego;
    bool Servicio;
    float PrecioSer;
    float Precio_riego;
    float IVA;
    float Precio_lote;
    bool Disp_lote;
    float Calcu_precio;
    bool Tipo_asper;	
};

#endif
