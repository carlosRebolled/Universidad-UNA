#include "lote.h"

Lote::Lote() {
    Id = 0;
    Estado = 'L';
    NombreC = " ";
    IdC = 0;
    Cant_repisa = 0;
    Cat_riego = false;
    Servicio = false;
    PrecioSer = 0;
    Precio_riego = 0;
    IVA = 0;
    Precio_lote = 0;
    Disp_lote = true;
    Calcu_precio = 0;
    Tipo_asper = false;
}

Lote::~Lote() {}

void Lote::setId(int id) {
    Id = id;
}

void Lote::setEstado(char estado) {
    Estado = estado;
}

void Lote::setNombreC(string nombreC) {
    NombreC = nombreC;
}

void Lote::setIdC(int idC) {
    IdC = idC;
}

void Lote::setCant_repisa(int cant_repisa) {
    Cant_repisa = cant_repisa;
}

void Lote::setCat_riego(bool cat_riego) {
    Cat_riego = cat_riego;
}

void Lote::setServicio(bool servicio) {
    Servicio = servicio;
}

void Lote::setPrecioSer(float precioSer) {
    PrecioSer = precioSer;
}

void Lote::setPrecio_riego(float precio_riego) {
    Precio_riego = precio_riego;
}

void Lote::setIVA(float iva) {
    IVA = iva;
}

void Lote::setPrecio_lote(float precio_lote) {
    Precio_lote = precio_lote;
}

void Lote::setDisp_lote(bool disp_lote) {
    Disp_lote = disp_lote;
}

void Lote::setCalcu_precio(float calcu_precio) {
    Calcu_precio = calcu_precio;
}

void Lote::setTipo_asper(bool tipo_asper) {
    Tipo_asper = tipo_asper;
}

int Lote::getId() {
    return Id;
}

char Lote::getEstado() {
    return Estado;
}

string Lote::getNombreC() {
    return NombreC;
}

int Lote::getIdC() {
    return IdC;
}

int Lote::getCant_repisa() {
    return Cant_repisa;
}

bool Lote::getCat_riego() {
    return Cat_riego;
}

bool Lote::getServicio() {
    return Servicio;
}

float Lote::getPrecioSer() {
    return PrecioSer;
}

float Lote::getPrecio_riego() {
    return Precio_riego;
}

float Lote::getIVA() {
    return IVA;
}

float Lote::getPrecio_lote() {
    return Precio_lote;
}

bool Lote::getDisp_lote() {
    return Disp_lote;
}

float Lote::getCalcu_precio() {
    return Calcu_precio;
}

bool Lote::getTipo_asper() {
    return Tipo_asper;
}

void Lote::calcular_iva() {
    IVA = (Precio_lote + Precio_riego + PrecioSer) * 0.13;
}

void Lote::calcular_precio_total() {
    Calcu_precio = Precio_lote + Precio_riego + PrecioSer + IVA;
}

double Lote::calcular_precio_5porciento() {
    return Precio_lote * 0.05;
}

double Lote::calcular_precio_15porciento() {
    return Precio_lote * 0.15;
}

double Lote::n_lotes_disponibles(Lote vector_lotes[10]) {
    int lotes_disp = 0;
    for (int vector_pos = 0; vector_pos < 10; vector_pos++) {
        if (vector_lotes[vector_pos].getDisp_lote()) {
            lotes_disp++;
        }
    }
    return lotes_disp;
}

void Lote::set_estado_lote(char estado_lote) {
    Estado = estado_lote;
    Disp_lote = (Estado == 'L');
}

string Lote::to_string() {
    stringstream s;
    s << "Id: " << Id << endl;
    s << "Estado: " << Estado << endl;
    s << "NombreC: " << NombreC << endl;
    s << "IdC: " << IdC << endl;
    s << "Cant_repisa: " << Cant_repisa << endl;
    s << "Cat_riego: " << Cat_riego << endl;
    s << "Servicio: " << Servicio << endl;
    s << "PrecioSer: " << PrecioSer << endl;
    s << "Precio_riego: " << Precio_riego << endl;
    s << "IVA: " << IVA << endl;
    s << "Precio_lote: " << Precio_lote << endl;
    s << "Disp_lote: " << Disp_lote << endl;
    s << "Calcu_precio: " << Calcu_precio << endl;
    return s.str();
}
