#include<iostream>
#include "LOTE.h"
using namespace std;

float calcularPrecio(int cantidadElegida) {
	float montoPorLote = 0;
	if (cantidadElegida == 1) {
		montoPorLote += 1500;
	} else if(cantidadElegida == 2) {
		montoPorLote += 1350;
	} else if(cantidadElegida == 3) {
		montoPorLote += 1200;
	} else {
		montoPorLote += 1050;
	}
	return montoPorLote;
}

int main (int argc, char *argv[]) {
	
	Lote vector_lotes[10];
	vector_lotes[0].setId(1);
	vector_lotes[1].setId(2);
	vector_lotes[2].setId(3);
	vector_lotes[3].setId(4);
	vector_lotes[4].setId(5);
	vector_lotes[5].setId(6);
	vector_lotes[6].setId(7);
	vector_lotes[7].setId(8);
	vector_lotes[8].setId(9);
	vector_lotes[9].setId(10);
	
	bool while_1 = true;
	
	int IdC = 0;
	string NombreC = " ";
	string opc_c;
	
	string opcion1, opcion2;
		
	opc_c = " ";
	while (while_1){
		


		cout << "Lotes libres: " << vector_lotes[8].n_lotes_disponibles(vector_lotes) << endl;
		cout << "" << endl;
		cout << "d.Disponibilidad de lotes" << endl;
		cout << "c.Comprar lotes" << endl;
		cout << "v.Ver info de lotes" << endl;
		cout << "i.Ver info de lotes por id cliente" << endl;
		cout << "s.Salir del programa" << endl;
		cout << "OPCION: " << endl;
		cin >> opc_c;
		
		if (opc_c == "d"){
			cout << "Lotes disponibles: " << vector_lotes[8].n_lotes_disponibles(vector_lotes) << endl;
			
			cout << "Digite enter para volver" << endl;
			cin.get();
			cin.get();
			system("cls");
		}
		
		if (opc_c == "v"){
			
			cout << "" << endl;
			for (int i = 0; i <= 9 ; i+=1){
				cout << vector_lotes[i].to_string() << endl;
			}
			
			cout << "Digite enter para volver" << endl;
			cin.get();
			cin.get();
			system("cls");
			
		}
		
		if (opc_c == "i"){
			
			cout << "Digite el id del cliente: ";
			cin >> IdC;
			
			cout << "" << endl;
			for (int i = 0; i <= 9 ; i+=1){
				if (vector_lotes[i].getIdC() == IdC){
					cout << vector_lotes[i].to_string() << endl;
				}
			}
			
			cout << "Digite enter para volver" << endl;
			cin.get();
			cin.get();
			system("cls");
			
			IdC = 0;
			
		}
		
		if (opc_c == "c"){
			
			
			if ( vector_lotes[8].n_lotes_disponibles(vector_lotes) > 0 ){
				cout << "" << endl; 
				
				cout << "Digite el id del cliente: ";
				cin >> IdC;
				
				cout << "Digite el nombre del cliente: ";
				cin >> NombreC;
				
				int cantidadLotes = 0;
				cout << "Cuantos lotes a comprar: ";
				cin >> cantidadLotes;
				
				while (0 >= cantidadLotes || vector_lotes[8].n_lotes_disponibles(vector_lotes) < cantidadLotes){
					cout << "Error, cantidad de lotes a comprar es invalida o mayor a los disponibles"<< endl;
					cout << "Lotes disponibles: " << vector_lotes[8].n_lotes_disponibles(vector_lotes) << endl;
					cout << "Cuantos lotes a comprar: ";
					cin >> cantidadLotes;
				}
				
				int idLotee = 1;
				double precioPorLotes = calcularPrecio(cantidadLotes);
				double precioServicioTotal = 0;
				double precioRiegoTotal = 0;
				double ivaTotal = 0;
				double totalTodo = 0;
				int cantRepisas = 0;
				
				for (int i = 0; i <= 9 ; i+=1){
					if (vector_lotes[i].getEstado() == 'L' && cantidadLotes >= idLotee ){
						
						cout << "LOTE " << idLotee << endl;
						cout << "Que tipo de servicio desea:" << endl;
						cout << "1. Estandar" << endl;
						cout << "2. Todo incluido" << endl;
						cout << "Ingrese la opcion: ";
						cin >> opcion1;
						
						while (opcion1 != "1" && opcion1 != "2") {
							cout << "Error: opcion invalida" << endl;
							cout << "Que tipo de servicio desea:" << endl;
							cout << "1. Estandar" << endl;
							cout << "2. Todo incluido" << endl;
							cout << "Ingrese la opcion: ";
							cin >> opcion1;
						}
						
						cout << "<Se ha guardado el servicio seleccionado>" << endl << endl;
						
						cout << "Que categoria de riego desea:" << endl;
						cout << "1. Normal" << endl;
						cout << "2. Aspersion mecanizada" << endl;
						cout << "Ingrese la opcion: ";
						cin >> opcion2;
						
						while (opcion2 != "1" && opcion2 != "2") {
							cout << "Error: opcion invalida" << endl;
							cout << "Que categoria de riego desea:" << endl;
							cout << "1. Normal" << endl;
							cout << "2. Aspersion mecanizada" << endl;
							cout << "Ingrese la opcion: ";
							cin >> opcion2;
						}
						
						cout << "<Se ha guardado el tipo de riego seleccionado>" << endl << endl;
						
						while (cantRepisas <= 0){
							cout << "Cantidad de repisas? (obligatorio) ";
							cin >> cantRepisas;
						}
						vector_lotes[i].setCant_repisa(cantRepisas);
						cantRepisas = 0;
						
						
						vector_lotes[i].setPrecio_lote( precioPorLotes );
						vector_lotes[i].setIdC(IdC);
						vector_lotes[i].setNombreC(NombreC);
						vector_lotes[i].set_estado_lote('O');
						
						if (opcion1 == "1"){
							vector_lotes[i].setServicio(false);
							vector_lotes[i].setPrecioSer( vector_lotes[i].calcular_precio_5porciento() );
						}else{
							vector_lotes[i].setServicio(true);
							vector_lotes[i].setPrecioSer( vector_lotes[i].calcular_precio_15porciento() );
						}
						
						if (opcion2 == "1"){
							vector_lotes[i].setCat_riego(false);
							vector_lotes[i].setTipo_asper(false);
							vector_lotes[i].setPrecio_riego( 0 );
							
							
						}else{
							vector_lotes[i].setCat_riego(true);
							vector_lotes[i].setTipo_asper(true);
							vector_lotes[i].setPrecio_riego( vector_lotes[i].calcular_precio_5porciento() );
							
						}
						
						vector_lotes[i].calcular_iva();
						vector_lotes[i].calcular_precio_total();
						
						precioServicioTotal += vector_lotes[i].getPrecioSer();
						precioRiegoTotal += vector_lotes[i].getPrecio_riego();
						ivaTotal += vector_lotes[i].getIVA();
						totalTodo += vector_lotes[i].getCalcu_precio();
						
						idLotee+=1;
					}
				}
				
				cout << ""<< endl;
				cout << "Precio por lote: " << precioPorLotes<< endl;
				cout << "Precio Servicio Total: " << precioServicioTotal<< endl;
				cout << "Precio Riego Total: " << precioRiegoTotal<< endl;
				cout << "IVA Total: " << ivaTotal<< endl;
				cout << "Precio por todo: " << totalTodo<< endl;
				cout << ""<< endl;
				
			}else {
				cout << "Error, no hay lotes para comprar" << endl;
			}
			
			cout << "Digite enter para volver" << endl;
			cin.get();
			cin.get();
			system("cls");
			
		}
		
		if (opc_c == "s"){
			while_1 = false;
		}
		
		if (opc_c != "v" && opc_c != "c" && opc_c != "s" && opc_c != "d" && opc_c != "i" ){
			cout << "Error, opcion diferente al de las del menu" << endl;
		}
		
		
		
	}
	return 0;
}

